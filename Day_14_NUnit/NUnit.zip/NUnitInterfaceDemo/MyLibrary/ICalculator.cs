﻿namespace MyLibrary
{
    public interface ICalculator
    {
        int Add(int a, int b);
        double Divide(double a, double b);
    }
}
